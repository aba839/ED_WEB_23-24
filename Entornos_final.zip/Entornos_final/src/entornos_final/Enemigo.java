package com.reinadomedac;
import java.lang.Math;

public class Enemigo {
    private String nombre;
    private int puntos_ataque;

    
    public Enemigo(String nombre) {
        this.nombre = nombre;

        puntos_ataque = 0;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getPuntos_ataque() {
        return puntos_ataque;
    }
    public void setPuntos_ataque(int puntos_ataque) {
        this.puntos_ataque = puntos_ataque;
    }

    public void calcularFuerzaEnemigo(){

        int random = (int) (Math.random()*10+1);
        setPuntos_ataque(random);
    
    }

    public int soltarDinero(){
        int random;
        return random = (int) (Math.random()*5+1);
    }
}
