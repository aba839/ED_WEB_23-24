package com.reinadomedac;

import java.lang.Math;

public class Jugador {
    private String nombre;
    private int puntos_salud, puntos_ataque, dinero;

    
    public Jugador(String nombre) {
        this.nombre = nombre;
        puntos_salud = 20;
        puntos_ataque = 3;
        dinero = 2;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getPuntos_salud() {
        return puntos_salud;
    }
    public void setPuntos_salud(int puntos_salud) {
        this.puntos_salud = puntos_salud;
    }
    public int getPuntos_ataque() {
        return puntos_ataque;
    }
    public void setPuntos_ataque(int puntos_ataque) {
        this.puntos_ataque = puntos_ataque;
    }

    public int getDinero(){
        return dinero;
    }

    public void setDinero(int dinero){
        this.dinero = dinero;
    }

    public void calcularFuerzaInicial(){

        int random = (int) (Math.random()*10+1);
        setPuntos_ataque(random);
    
    }
    @Override
    public String toString() {
        return "Jugador [puntos_salud=" + puntos_salud + ", puntos_ataque=" + puntos_ataque + ", dinero=" + dinero
                + "]";
    }
    
    
}
