package com.reinadomedac;

import java.util.Scanner;
import java.lang.Math;


public class Main {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        String nombre;
        Jugador jugador1;
        Enemigo enemigo;
        Boolean salir = true;
        int opcion, opcion_compra, random, dinero_recibido, puntos_salud_perdidos; 
        String[] nombres_enemigos = {"Jose", "Javi", "Luis", "Miguel"};


        System.out.println("Bienvenido/a al reinado de Medac");
        System.out.println("Introduce tu nombre");
        nombre = teclado.nextLine();
        jugador1 = new Jugador(nombre);

        System.out.println("Vamos a calcular tu fuerza inicial...");
        jugador1.calcularFuerzaInicial();
        System.out.println("Tu fuerza inicial es de... " + jugador1.getPuntos_ataque() + " puntos!");
       
        System.out.println("Pulse 1 Si quieres cambiar de forma aleatoria tu fuerza inicial (cuesta 1 oro)");
        System.out.println("Pulse 2 para continuar el juego");
        opcion = teclado.nextInt();
        if(opcion == 1){
            jugador1.calcularFuerzaInicial();
            System.out.println("Tu fuerza inicial es de... " + jugador1.getPuntos_ataque() + " puntos!");
            jugador1.setDinero(jugador1.getDinero()-1);
            
        }
        else if(opcion == 2){
            System.out.println("Decides quedate con tus " + jugador1.getPuntos_ataque() + " puntos de ataque");
        }
        else{
            System.out.println("Opción incorrecta, el juego va a continuar");
        }

        System.out.println(nombre + " tu aventura empieza ahora...¡Conquista Medac!");

        do{

            menu_principal();
            opcion = teclado.nextInt();
            switch(opcion){
                case 1:
                    System.out.println("Has encontrado un enemigo!!");
                    random = (int) (Math.random()*4);
                    enemigo = new Enemigo(nombres_enemigos[random]);
                    System.out.println("Vas a enfrentarte a... " + enemigo.getNombre() + "!!!");
                    enemigo.calcularFuerzaEnemigo();
                    System.out.println("Tienes " + jugador1.getPuntos_ataque() + " puntos de ataque y " + enemigo.getNombre() + " tiene " + enemigo.getPuntos_ataque() + " puntos de ataque");
                    if(jugador1.getPuntos_ataque() >= enemigo.getPuntos_ataque()){

                        dinero_recibido = enemigo.soltarDinero();
                        System.out.println("Has ganado el combate!! Has recibido " + dinero_recibido + " oros" + " al vencer a " + enemigo.getNombre());
                        jugador1.setDinero(jugador1.getDinero()+dinero_recibido);

                    }
                    else{
                        puntos_salud_perdidos = enemigo.getPuntos_ataque() - jugador1.getPuntos_ataque();
                        System.out.println(enemigo.getNombre() + " te ha machacado y has perdido " + puntos_salud_perdidos + " puntos de salud");
                        jugador1.setPuntos_salud(jugador1.getPuntos_salud()-puntos_salud_perdidos);
                        if(jugador1.getPuntos_salud() <= 0){
                            System.out.println("Game Over");
                            salir = false;
                        }
                    }
                break;
                case 2:
                    bazarteria();
                    opcion_compra = teclado.nextInt();
                    if(opcion_compra == 1 && jugador1.getDinero() >= 5){
                        System.out.println  ("Has comprado una calculadora");
                        jugador1.setPuntos_ataque(jugador1.getPuntos_ataque()+3);
                        jugador1.setDinero(jugador1.getDinero()-5);
                    }
                    else if(opcion_compra == 2 && jugador1.getDinero() >= 7){
                        System.out.println("Has comprado un puño americano");
                        jugador1.setPuntos_ataque(jugador1.getPuntos_ataque()+5);
                        jugador1.setDinero(jugador1.getDinero()-7);
                    }
                    else if(opcion_compra == 3  && jugador1.getDinero() >= 10){
                        System.out.println("Has comprado un martillo");
                        jugador1.setPuntos_ataque(jugador1.getPuntos_ataque()+7);
                        jugador1.setDinero(jugador1.getDinero()-10);
                    }
                    else if(opcion_compra == 4  && jugador1.getDinero() >= 8){
                        System.out.println("Has comprado vendas");
                        jugador1.setPuntos_salud(jugador1.getPuntos_salud()+5);
                        jugador1.setDinero(jugador1.getDinero()-8);
                    }
                    else{
                        System.out.println("No tienes fondos o has elegido una opción incorrecta");
                    }

                break;
                case 3:
                    System.out.println(jugador1);
                    break;
                case 4:
                    System.out.println("¡Gracias por jugar, hasta pronto!");
                    salir = false;
                break;
                default:
                    System.out.println("Opción incorrecta, inténtelo de nuevo.");
                break;
            }
        }while(salir == true);
        
        teclado.close();

    }
    public static void bazarteria(){
        System.out.println("Visitas la Bazartería para comprar un arma");
        System.out.println("¿Qué deseas comprar?");
        System.out.println("1. Calculadora -> +3p de ataque -> 5 oros");
        System.out.println("2. Puño americano -> +5p de ataque -> 7 oros");
        System.out.println("3. Martillo -> +7p de ataque -> 10 oros");
        System.out.println("4. Vendas -> +5p de salud -> 8 oros");
    }

    public static void menu_principal(){
        System.out.println("Pulse 1 para luchar contra un enemigo");
        System.out.println("Pulse 2 para buscar comprar un arma");
        System.out.println("Pulse 3 para consultar tus estadísticas");
        System.out.println("Pulse 4 para salir");
    }
}